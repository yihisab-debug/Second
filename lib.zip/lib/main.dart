import 'dart:convert';
import 'package:flutter/material.dart';
import 'package:http/http.dart' as http;

void main() {
  runApp(const MyApp());
}

class MyApp extends StatelessWidget {
  const MyApp({super.key});

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'Регистрация',
      theme: ThemeData(primarySwatch: Colors.blue),
      home: const RegisterScreen(),
    );
  }
}

class RegisterScreen extends StatefulWidget {
  const RegisterScreen({super.key});

  @override
  State<RegisterScreen> createState() => _RegisterScreenState();
}

class _RegisterScreenState extends State<RegisterScreen> {
  final _loginController = TextEditingController();
  final _passwordController = TextEditingController();
  final _nameController = TextEditingController();

  bool _isLoading = false;
  String _resultMessage = '';



  final String apiUrl = 'http://api.com/api/user/register';




  Future<void> _register() async {
    final login = _loginController.text.trim();
    final password = _passwordController.text.trim();
    final name = _nameController.text.trim();

    if (login.isEmpty || password.isEmpty) {
      setState(() {
        _resultMessage = 'Заполните логин и пароль';
      });
      return;
    }

    setState(() {
      _isLoading = true;
      _resultMessage = '';
    });

    try {
      final response = await http.post(
        Uri.parse(apiUrl),
        body: {
          'login': login,
          'password': password,
          'name': name,
        },
      );

      final data = jsonDecode(response.body);

      setState(() {
        _isLoading = false;
        if (data['status'] == 200) {
          _resultMessage = 'Регистрация успешна!';
        } else if (data['status'] == 409) {
          _resultMessage = 'Такой пользователь уже существует';
        } else {
          _resultMessage = 'Ошибка: ${data['message'] ?? 'неизвестная ошибка'}';
        }
      });
    } catch (e) {
      setState(() {
        _isLoading = false;
        _resultMessage = 'Ошибка соединения: $e';
      });
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text('Регистрация')),
      
      body: Padding(
        padding: const EdgeInsets.all(24.0),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.stretch,
          children: [

            TextField(
              controller: _loginController,
              decoration: const InputDecoration(labelText: 'Логин'),
            ),

            const SizedBox(height: 12),

            TextField(
              controller: _passwordController,
              decoration: const InputDecoration(labelText: 'Пароль'),
              obscureText: true,
            ),

            const SizedBox(height: 12),

            TextField(
              controller: _nameController,
              decoration: const InputDecoration(labelText: 'Имя'),
            ),

            const SizedBox(height: 24),

            ElevatedButton(
              onPressed: _isLoading ? null : _register,
              child: _isLoading
                  ? const SizedBox(
                      height: 20,
                      width: 20,
                      child: CircularProgressIndicator(strokeWidth: 2),
                    )
                  : const Text('Зарегистрироваться'),
            ),

            const SizedBox(height: 16),

            if (_resultMessage.isNotEmpty)

              Text(
                _resultMessage,
                style: TextStyle(
                  color: _resultMessage.contains('успешна')
                      ? Colors.green
                      : Colors.red,
                ),
              ),

          ],
        ),
      ),
    );
  }
}
